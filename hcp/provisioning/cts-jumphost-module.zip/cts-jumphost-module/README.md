## EC2 Jumphost with Security Groups module for Consul Terraform Sync

This Terraform module maintains a security group that allows SSH towards every service from the Consul catalog. Using the module in automation with [Consul Terraform Sync](https://www.consul.io/docs/nia) will dynamically add or remove firewall destination rules from the security group based on [Consul service discovery](https://www.consul.io/).

## Feature

The module creates destination rules for port 22 and applies them to a security group. The module is scheduled to sync the ruleset every minute.

## Requirements

### Ecosystem Requirements

| Ecosystem | Version |
|-----------|---------|
| [consul](https://www.consul.io/downloads) | >= 1.16 |
| [consul-terraform-sync](https://www.consul.io/docs/nia) | >= 0.1.0 |
| [terraform](https://www.terraform.io) | >= 0.13 |

### Terraform Providers

| Name | Version |
|------|---------|
| hashicorp/aws | ~> 3.43 |

## Setup

Prerequisites:

- a working set of credetials for AWS is the only prerequisite
- a deployed VPC with a security-group in an AWS region

Here's a sample invocation of the module to track only service instances with an `nginx` name:

```
task {
  name      = "jumphost-ssh"
  description = "execute every minute using service information from nginx"
  module    = "/opt/consul-nia/cts-jumphost-module"
  providers = ["aws"]
  variable_files = ["/opt/consul-nia/cts-jumphost-module.tfvars"]

  condition "schedule" {
    cron = "* * * * *" # every minute
  }

  module_input "services" {
    names = "nginx"
  }
}
```

**User Config for Consul Terraform Sync**

example.hcl
```hcl
driver "terraform" {
  log         = false
  persist_log = true
  path        = ""

  backend "consul" {
    gzip = true
  }

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 3.43"
    }
  }
}

terraform_provider "aws" {
}

task {
  name      = "jumphost-ssh"
  description = "execute every minute using service information from nginx"
  module    = "/opt/consul-nia/cts-jumphost-module"
  providers = ["aws"]
  variable_files = ["/opt/consul-nia/cts-jumphost-module.tfvars"]

  condition "schedule" {
    cron = "* * * * *" # every minute
  }

  module_input "services" {
    names = "nginx"
  }
}
```